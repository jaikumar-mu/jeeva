// background.js — Toposketch Collector v10 (MV3 service worker)
// Performs network requests for content scripts. Extension service workers
// with host_permissions are exempt from CORS and from the page's CSP, which
// is what made OTP / Firestore / Overpass calls fail on openstreetmap.org.

const ALLOWED_HOSTS = new Set([
  'toposketch-proxy.vercel.app',
  'firestore.googleapis.com',
  'overpass-api.de',
  'overpass.private.coffee',
  'overpass.kumi.systems',
  'api.openstreetmap.org',
  'identitytoolkit.googleapis.com',
  'firebase-auth-worker.bmkumar07.workers.dev',
]);

async function doFetch(req) {
  let u;
  try { u = new URL(req.url); } catch (e) { return { networkError: 'Bad URL' }; }
  if (u.protocol !== 'https:' || !ALLOWED_HOSTS.has(u.hostname)) {
    return { networkError: 'Host not allowed: ' + u.hostname };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45000);
  try {
    const r = await fetch(req.url, {
      method: req.method || 'GET',
      headers: req.headers || {},
      body: ['GET', 'HEAD'].includes(req.method) ? undefined : req.body,
      signal: controller.signal,
      cache: 'no-store',
    });
    const body = await r.text();
    const headers = {};
    r.headers.forEach((v, k) => { headers[k] = v; });
    return { status: r.status, statusText: r.statusText, headers, body };
  } catch (e) {
    return { networkError: e.name === 'AbortError' ? 'Timeout (45s)' : (e.message || String(e)) };
  } finally {
    clearTimeout(timer);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'TOPO_FETCH') return false;
  if (sender.id !== chrome.runtime.id) return false;
  doFetch(msg.req).then(sendResponse);
  return true; // keep the channel open for the async response
});
