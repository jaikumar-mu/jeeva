TOPOSKETCH COLLECTOR v13 — CHANGES (Sep 2026)
v13: SECURE CREDITS. The extension no longer writes to Firestore.
     Reading your record, registering and using a credit all go through
     toposketch-proxy (/api/me, /api/register, /api/use-credit) with a
     90-day login token issued after OTP. Everyone logs in again once.
     Needs the matching toposketch-proxy files + locked Firestore rules.

v12 CHANGES (Sep 2026)
v12: Price shown as ₹499 (Razorpay Payment Page must also be ₹499).
     Webhook credits ONLY ₹499 payments, so SWP payments never mix in.

v11: FIXED "Overpass error: Overpass HTTP 406" in Circle Mode — Overpass is
     called directly from the OSM page (proper Referer), with automatic
     fallback to mirror servers (private.coffee, kumi.systems).

v10 CHANGES
=============================================
FIXED: OTP "Failed to fetch" on openstreetmap.org
  - All external calls (OTP proxy, Firestore, Overpass, OSM API) now go
    through background.js (extension service worker). It is not blocked by
    CORS or by OpenStreetMap's Content-Security-Policy.
FIXED: "Executing inline script violates Content Security Policy"
  - The map-drawing bridge is now a real file (osm-bridge-main.js) that runs
    in the page world, instead of an inline <script>.
REMOVED: topo-auth-interceptor.js (its token was never set; replaced by
  net-bridge.js).
DEBUG: F12 Console shows one line per request:
  [TOPO Net] ✅ GET .../api/send-otp → 200
  [TOPO Net] ⚠️ ... → HTTP 500 <server message>   (server-side problem)
  [TOPO Net] ❌ ... → <network error>              (cannot reach server)
REQUIRES: Chrome / Edge 111 or newer.
LOGOUT: on openstreetmap.org press F12 → Console → type:
  localStorage.removeItem('topo_session')   then press F5.

OSM Road Vertex Collector v1.0 — Chrome / Edge
================================================
Built from TNGIS Plot Vertex Collector v4.0 by B. Muthukumar

WHAT THIS DOES
--------------
Opens a panel on the OpenStreetMap iD editor page.
Click any road (way) on the OSM map → the extension automatically
collects all vertex lat/lon coordinates of that road.

Shows:
  • SVG road preview with segment lengths on each side
  • Road info: OSM tags (name, highway type, ref, etc.)
  • Total road length in metres, feet, kilometres
  • Full vertex table: #, Node ID, Latitude, Longitude, Segment Length

Exports:
  • DXF  — metric projected coordinates (AutoCAD-ready, correct distances)
  • CSV  — all vertices with Node ID, lat, lon, seg lengths (Excel-ready)
  • Text — lat,lon per vertex (GIS / Google Earth format)
  • CAD Text — lon,lat per vertex (paste into AutoCAD PLINE command)


HOW IT COLLECTS VERTEX DATA — TWO STRATEGIES
---------------------------------------------
Strategy 1 (instant — no network call):
  Reads the iD editor's internal JavaScript data store to get
  the selected way's nodes with exact lat/lon. Works immediately
  when iD has the data loaded in memory.

Strategy 2 (OSM API fallback — ~1 second):
  When a road is selected, iD editor updates the URL to:
    https://www.openstreetmap.org/edit?way=123456789
  The extension reads the way ID from the URL and calls:
    https://api.openstreetmap.org/api/0.6/way/{id}/full.json
  This returns all nodes with exact lat/lon coordinates.

Both strategies run automatically — you do not need to choose.


HOW TO USE
----------
1. Go to: https://www.openstreetmap.org/edit
2. The green panel appears at bottom-right.
3. Enable Map Data: press F key or click the map layers icon.
4. Click any road on the map — it is collected automatically.
   OR: click the road to select it, then click [Collect] button.
5. View vertex table, preview, and lengths in the panel.
6. Export as needed (DXF / CSV / Text / CAD Text).


HOW TO USE DXF IN AUTOCAD
--------------------------
1. Click [DXF] → saves OSM_Roads.dxf
2. AutoCAD: File → Open → select the .dxf file
3. Type: ZOOM → Enter → E → Enter  (zoom to extents)
4. To check segment: click a VERTEX entity → type LIST → Enter
5. Layers in DXF:
     R_<RoadName>   — open POLYLINE of the road (metric metres)
     EDGE_LENGTHS   — text labels for each segment length
     ROAD_LABELS    — road name, type, and total length at midpoint

NOTE: Coordinates use a local Transverse Mercator projection
      centred on the average of all collected roads.
      Origin = (0,0). Units = metres.
      AutoCAD DIST and PROPERTIES commands show correct metric values.


AUTOCAD PLINE PASTE (CAD Text export)
--------------------------------------
1. Click [CAD Text] → saves OSM_Roads_CAD.txt
2. Open the file — coordinates are in  lon,lat  order per line
3. In AutoCAD: type PLINE → Enter
4. Paste the coordinate lines one by one (or use a script)
5. Press Enter to finish the polyline


BUTTONS
-------
  Collect   → manually collect currently selected road
  DXF       → AutoCAD file with metric projected coordinates
  CSV       → Excel spreadsheet (Node ID, lat, lon, segment lengths)
  Text      → lat,lon per vertex (GIS format)
  CAD Text  → lon,lat per vertex (AutoCAD PLINE paste)
  Undo      → remove last collected road
  Clear     → remove all roads


MULTIPLE ROADS
--------------
Collect as many roads as you want — they stack in the panel.
Click the road name tabs above the preview to switch between them.
DXF exports ALL collected roads, each on its own named layer.
CSV exports ALL roads in one file with a Way ID column.
Total length is shown when 2 or more roads are collected.


INSTALL
-------
1. Open Chrome / Edge
2. Go to: chrome://extensions  (or edge://extensions)
3. Enable Developer mode (toggle, top-right)
4. Click [Load unpacked]
5. Select the folder containing these files:
     content.js
     manifest.json
     panel.css
     README.txt
6. Open: https://www.openstreetmap.org/edit
7. The 🛣 OSM Road Vertex Collector panel appears automatically.


DIFFERENCES FROM TNGIS PLOT COLLECTOR
--------------------------------------
  TNGIS                       OSM Road Collector
  ─────────────────────────   ────────────────────────────────
  Closed polygon (plot)       Open polyline (road)
  Area in 6 units             Road length in m / ft / km
  Survey Number + Sub Div     OSM tags (name, highway, ref...)
  HTML table scraping         iD editor JS store + OSM API
  tngis.tn.gov.in             www.openstreetmap.org/edit
  DXF: POLYLINE 70\1 (closed) DXF: POLYLINE 70\0 (open)
  Area text label             Road name + type + length label


CREDITS
-------
  Built on TNGIS Plot Vertex Collector v4.0
  Original author: B. Muthukumar (B.E), Madurai
  Projection math: simplified Transverse Mercator, WGS-84
  OSM data: © OpenStreetMap contributors (ODbL licence)
