// net-bridge.js — Toposketch Collector v10
// Loaded BEFORE content.js (same isolated world).
//
// WHY: On openstreetmap.org, fetch() calls made directly from the content
// script to toposketch-proxy.vercel.app / Firestore / Overpass fail with
// "TypeError: Failed to fetch" (page-origin CORS + OSM's strict CSP).
// FIX: every external request is relayed to background.js (the extension
// service worker). The service worker is covered by host_permissions, so it
// is NOT subject to CORS or to OSM's Content-Security-Policy.
(function () {
  'use strict';
  if (window.__TOPO_NET_BRIDGE__) return;
  window.__TOPO_NET_BRIDGE__ = true;

  // 1) Stop content.js from injecting its inline <script> bridge (blocked by
  //    OSM CSP). The real bridge now loads as osm-bridge-main.js (MAIN world).
  //    content.js skips injection when an element with id="osm-bridge" exists.
  try {
    if (!document.getElementById('osm-bridge')) {
      const marker = document.createElement('meta');
      marker.id = 'osm-bridge';
      marker.name = 'toposketch-bridge';
      (document.head || document.documentElement).appendChild(marker);
    }
  } catch (e) { /* ignore */ }

  // 2) Relay external fetch() calls through the background service worker.
  const RELAY_HOSTS = [
    'toposketch-proxy.vercel.app',
    'firestore.googleapis.com',
    'overpass-api.de',
    'api.openstreetmap.org',
    'identitytoolkit.googleapis.com',
    'firebase-auth-worker.bmkumar07.workers.dev',
  ];

  const origFetch = window.fetch.bind(window);

  function headersToObject(h) {
    const out = {};
    if (!h) return out;
    if (h instanceof Headers) { h.forEach((v, k) => { out[k] = v; }); return out; }
    if (Array.isArray(h)) { h.forEach(([k, v]) => { out[k] = v; }); return out; }
    return Object.assign(out, h);
  }

  function bodyToString(b) {
    if (b == null) return undefined;
    if (typeof b === 'string') return b;
    if (b instanceof URLSearchParams) return b.toString();
    return String(b);
  }

  function relay(req) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage({ type: 'TOPO_FETCH', req }, (res) => {
          const err = chrome.runtime.lastError;
          if (err) return reject(new TypeError('Relay error: ' + err.message));
          if (!res) return reject(new TypeError('Relay error: no response from background'));
          resolve(res);
        });
      } catch (e) {
        // Happens after the extension is reloaded while the tab stays open
        reject(new TypeError('Extension was reloaded — please refresh this page (F5). ' + e.message));
      }
    });
  }

  // Overpass (Circle Mode) and the OSM API must be called DIRECTLY from the
  // page so the request carries Origin/Referer = www.openstreetmap.org.
  // Since 2026 overpass-api.de rejects requests without a proper browser
  // referrer with "HTTP 406 Not Acceptable" (the background worker cannot
  // send a Referer). If the main Overpass server is busy/blocking, mirrors
  // are tried automatically.
  const DIRECT_FIRST = ['overpass-api.de', 'api.openstreetmap.org'];
  const OVERPASS_MIRRORS = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
  ];
  const RETRY_STATUS = [406, 429, 502, 503, 504];

  function buildReq(url, init) {
    return {
      url,
      method: ((init && init.method) || 'GET').toUpperCase(),
      headers: headersToObject(init && init.headers),
      body: bodyToString(init && init.body),
    };
  }

  async function viaRelay(url, init) {
    const req = buildReq(url, init);
    const res = await relay(req);
    if (res.networkError) {
      console.error('[TOPO Net] ❌', req.method, url.split('?')[0], '→', res.networkError);
      throw new TypeError('Failed to fetch (' + res.networkError + ')');
    }
    if (res.status >= 400) {
      console.warn('[TOPO Net] ⚠️', req.method, url.split('?')[0], '→ HTTP', res.status, (res.body || '').slice(0, 300));
    } else {
      console.log('[TOPO Net] ✅', req.method, url.split('?')[0], '→', res.status);
    }
    const nullBody = [101, 204, 205, 304].includes(res.status);
    return new Response(nullBody ? null : (res.body ?? ''), {
      status: res.status,
      statusText: res.statusText || '',
      headers: res.headers || {},
    });
  }

  async function directThenRelay(url, init) {
    try {
      const r = await origFetch(url, Object.assign({}, init, { referrerPolicy: 'strict-origin-when-cross-origin' }));
      console.log('[TOPO Net] ' + (r.ok ? '✅' : '⚠️') + ' (direct)', (init.method || 'GET').toUpperCase(), url.split('?')[0], '→', r.status);
      return r;
    } catch (e) {
      console.warn('[TOPO Net] direct call blocked, using background:', url.split('?')[0], e.message);
      return viaRelay(url, init);
    }
  }

  async function overpassFetch(url, init) {
    let last = null, lastErr = null;
    const list = [url, ...OVERPASS_MIRRORS.filter(m => m !== url)];
    for (const u of list) {
      try {
        const r = await directThenRelay(u, init);
        if (r.ok || !RETRY_STATUS.includes(r.status)) return r;
        console.warn('[TOPO Net] Overpass', new URL(u).hostname, 'HTTP', r.status, '→ trying next server');
        last = r;
      } catch (e) {
        lastErr = e;
      }
    }
    if (last) return last;
    throw lastErr || new TypeError('Failed to fetch (all Overpass servers)');
  }

  // ── v13: secure credits. Firestore is no longer written by the extension.
  //    User record read / register / credit use go through toposketch-proxy,
  //    authenticated by a login token issued after OTP verification.
  const PROXY = 'https://toposketch-proxy.vercel.app';
  const TOKEN_KEY = 'topo_token', SESSION_KEY = 'topo_session';
  let otpState = null; // { session, mobile, sig } from the last send-otp

  function getToken() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (e) { return ''; } }
  function setToken(t) { try { localStorage.setItem(TOKEN_KEY, t); } catch (e) {} }
  function clearLogin() {
    try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(SESSION_KEY); } catch (e) {}
  }
  // Old logins (before v13) have no token → ask for OTP once more.
  try {
    const hasSession = !!localStorage.getItem(SESSION_KEY);
    const hasToken = !!localStorage.getItem(TOKEN_KEY);
    if (hasSession && !hasToken) { localStorage.removeItem(SESSION_KEY); console.log('[TOPO] Please log in again (one-time, security upgrade)'); }
    if (!hasSession && hasToken) localStorage.removeItem(TOKEN_KEY);
  } catch (e) {}

  let reloading = false;
  function loginExpired() {
    clearLogin();
    if (!reloading) {
      reloading = true;
      alert('Toposketch: your login has expired. Please log in again with OTP.');
      location.reload();
    }
  }

  async function proxyCall(path, method, bodyObj) {
    const headers = { 'Content-Type': 'application/json' };
    const t = getToken();
    if (t) headers.Authorization = 'Bearer ' + t;
    const r = await viaRelay(PROXY + path, { method, headers, body: bodyObj ? JSON.stringify(bodyObj) : undefined });
    if (r.status === 401) loginExpired();
    return r;
  }

  async function handleSecure(url, init) {
    const u = new URL(url);
    const method = (init.method || 'GET').toUpperCase();

    // OTP send: remember session + signature for the verify step
    if (u.hostname === 'toposketch-proxy.vercel.app' && u.pathname === '/api/send-otp') {
      const r = await viaRelay(url, init);
      try {
        const j = await r.clone().json();
        if (j.Status === 'Success' && j.Details) {
          otpState = { session: j.Details, mobile: (u.searchParams.get('mobile') || '').replace(/\D/g, '').slice(-10), sig: j.topoSig || '' };
        }
      } catch (e) {}
      return r;
    }

    // OTP verify: add mobile + signature, store the login token
    if (u.hostname === 'toposketch-proxy.vercel.app' && u.pathname === '/api/verify-otp') {
      if (otpState && otpState.session === u.searchParams.get('session')) {
        u.searchParams.set('mobile', otpState.mobile);
        u.searchParams.set('sig', otpState.sig);
      }
      const r = await viaRelay(u.toString(), init);
      try {
        const j = await r.clone().json();
        if (j.Status === 'Success') {
          if (j.topoToken) { setToken(j.topoToken); console.log('[TOPO] 🔑 Logged in securely'); }
          else console.warn('[TOPO] OTP ok but no login token received');
        }
      } catch (e) {}
      return r;
    }

    // Firestore user record → server
    if (u.hostname === 'firestore.googleapis.com' && /\/documents\/users\/topo_91\d{10}$/.test(u.pathname)) {
      if (method === 'GET') {
        if (!getToken()) return new Response('{"error":{"code":404}}', { status: 404, headers: { 'Content-Type': 'application/json' } });
        return proxyCall('/api/me', 'GET');
      }
      if (method === 'PATCH') {
        let fields = {};
        try { fields = JSON.parse(init.body || '{}').fields || {}; } catch (e) {}
        if (u.searchParams.getAll('updateMask.fieldPaths').includes('credits')) {
          return proxyCall('/api/use-credit', 'POST', {});           // DXF export
        }
        return proxyCall('/api/register', 'POST', { name: (fields.name && fields.name.stringValue) || '' }); // new user
      }
    }
    return null;
  }

  window.fetch = async function (input, init = {}) {
    const url = typeof input === 'string' ? input : (input && input.url) || String(input);
    let host = '';
    try { host = new URL(url, location.href).hostname; } catch (e) {}
    init = init || {};

    if (host === 'toposketch-proxy.vercel.app' || host === 'firestore.googleapis.com') {
      const r = await handleSecure(url, init);
      if (r) return r;
    }
    if (host === 'overpass-api.de') return overpassFetch(url, init);
    if (DIRECT_FIRST.includes(host)) return directThenRelay(url, init);
    if (!RELAY_HOSTS.includes(host)) return origFetch(input, init);
    return viaRelay(url, init);
  };

  // 3) Show the Toposketch price as ₹499 in the panel (content.js has ₹500 built in).
  //    Only text inside the Toposketch panel changes; nothing else on the page.
  const OLD_PRICE = '₹500', NEW_PRICE = '₹499';
  function fixPrice(root) {
    try {
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while ((n = w.nextNode())) {
        if (n.nodeValue.includes(OLD_PRICE)) n.nodeValue = n.nodeValue.split(OLD_PRICE).join(NEW_PRICE);
      }
    } catch (e) {}
  }
  function startPriceFix() {
    if (!document.body) return setTimeout(startPriceFix, 300);
    fixPrice(document.body);
    new MutationObserver((muts) => {
      for (const m of muts) {
        for (const node of m.addedNodes) {
          if (node.nodeType === 1) fixPrice(node);
          else if (node.nodeType === 3 && node.nodeValue.includes(OLD_PRICE)) node.nodeValue = node.nodeValue.split(OLD_PRICE).join(NEW_PRICE);
        }
        if (m.type === 'characterData' && m.target.nodeValue.includes(OLD_PRICE)) m.target.nodeValue = m.target.nodeValue.split(OLD_PRICE).join(NEW_PRICE);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  startPriceFix();

  console.log('[TOPO Net] Bridge loaded ✅ (external calls go via background)');
})();
