// osm-bridge-main.js — Toposketch Collector v10
// Runs in the PAGE (MAIN) world as a real extension file, so OpenStreetMap's
// Content-Security-Policy no longer blocks it (it used to be injected as an
// inline <script>, which OSM refuses: "Executing inline script violates CSP").
// Draws the clip circle / pins / collected features on the OSM Leaflet map.
(function(){
    var _layers={};
    function getMap(){
      try{
        if(window.map && window.map.addLayer && window.map.latLngToContainerPoint) return window.map;
        var els=document.querySelectorAll(".leaflet-container, #map");
        for(var i=0;i<els.length;i++){
          var el=els[i];
          if(el._leaflet_map && el._leaflet_map.addLayer) return el._leaflet_map;
          var names=Object.getOwnPropertyNames(el);
          for(var j=0;j<names.length;j++){
            var v; try{v=el[names[j]];}catch(e){continue;}
            if(v && typeof v.addLayer==="function" && typeof v.latLngToContainerPoint==="function" && typeof v.getContainer==="function") return v;
          }
        }
        // Last resort: inspect descendants for a stored Leaflet map reference.
        var all=document.querySelectorAll("*");
        for(var a=0;a<all.length;a++){
          var names2=Object.getOwnPropertyNames(all[a]);
          for(var b=0;b<names2.length;b++){
            var v2; try{v2=all[a][names2[b]];}catch(e){continue;}
            if(v2 && typeof v2.addLayer==="function" && typeof v2.latLngToContainerPoint==="function" && typeof v2.getContainer==="function") return v2;
          }
        }
      }catch(e){ console.warn("OSM Bridge map detection failed",e); }
      return null;
    }
    document.addEventListener("osm-draw",function(ev){
      var d=ev.detail, lmap=getMap();
      if(!lmap||!window.L){console.warn("OSM Bridge: no map or L",{map:!!lmap,L:!!window.L});return;}
      // Clear group
      (_layers[d.group]||[]).forEach(function(l){try{lmap.removeLayer(l);}catch(e){}});
      _layers[d.group]=[];
      if(d.clear) return;
      var nl=[];
      // Keep our drawing above the normal OSM street/label layers.
      // This is especially important on the standard Street Map where
      // the circle can otherwise be visually lost among map graphics.
      try{
        if(!lmap.getPane("osm-user-overlay")){
          lmap.createPane("osm-user-overlay");
          lmap.getPane("osm-user-overlay").style.zIndex=650;
          lmap.getPane("osm-user-overlay").style.pointerEvents="none";
        }
      }catch(e){}
      var pane="osm-user-overlay";
      if(d.type==="circle"){
        // Custom Leaflet circle: deliberately use our own pane + SVG renderer.
        // This avoids DOM positioning problems on OSM's map container.
        var cPane=lmap.getPane("osm-user-overlay");
        cPane.style.zIndex=10000;
        var circle=L.circle([d.lat,d.lon],{
          pane:"osm-user-overlay",
          radius:Number(d.radius)||500,
          color:"#ff0033",
          weight:10,
          opacity:1,
          fillColor:"#ff1744",
          fillOpacity:0.28,
          bubblingMouseEvents:false,
          interactive:false,
          className:"osm-my-radius-circle"
        }).addTo(lmap);
        try{circle.bringToFront();}catch(e){}

        // Strong center target, also in our topmost pane.
        var center=L.circleMarker([d.lat,d.lon],{
          pane:"osm-user-overlay",
          radius:11,
          color:"#ffffff",
          weight:4,
          opacity:1,
          fillColor:"#ff0033",
          fillOpacity:1,
          interactive:false,
          className:"osm-my-radius-center"
        }).addTo(lmap);
        try{center.bringToFront();}catch(e){}

        nl.push(circle,center);
      } else if(d.type==="pin"){


        nl.push(L.circleMarker([d.lat,d.lon],{pane:pane,radius:9,
          color:"#dc2626",weight:3,fillColor:"#fca5a5",fillOpacity:0.9}).addTo(lmap));
        // Draw line from pin to circle centre if provided
        if(d.cLat!==undefined){
          nl.push(L.polyline([[d.lat,d.lon],[d.cLat,d.cLon]],
            {pane:pane,color:"#dc2626",weight:3,dashArray:"6,6",opacity:0.95}).addTo(lmap));
        }
      } else if(d.type==="polyline"){
        nl.push(L.polyline(d.latlngs,
          {color:d.color||"#f97316",weight:d.weight||4,opacity:0.9}).addTo(lmap));
      } else if(d.type==="polygon"){
        nl.push(L.polygon(d.latlngs,
          {color:d.color||"#f97316",weight:2,opacity:0.9,
           fillColor:d.fillColor||"#fed7aa",fillOpacity:0.3}).addTo(lmap));
      } else if(d.type==="marker"){
        nl.push(L.circleMarker([d.lat,d.lon],
          {pane:pane,radius:8,color:d.color||"#f97316",weight:2,
           fillColor:d.color||"#fed7aa",fillOpacity:0.8}).addTo(lmap));
      } else if(d.type==="batch"){
        d.features.forEach(function(f){
          if(f.latlngs&&f.latlngs.length>=3&&f.closed)
            nl.push(L.polygon(f.latlngs,
              {color:f.color,weight:1.5,fillColor:f.color,fillOpacity:0.15}).addTo(lmap));
          else if(f.latlngs&&f.latlngs.length>=2)
            nl.push(L.polyline(f.latlngs,
              {color:f.color,weight:2.5,opacity:0.8}).addTo(lmap));
          else if(f.lat!==undefined)
            nl.push(L.circleMarker([f.lat,f.lon],
              {radius:5,color:f.color,weight:1.5,
               fillColor:f.color,fillOpacity:0.7}).addTo(lmap));
        });
      }
      _layers[d.group]=nl;
    });
    document.addEventListener("osm-goto",function(ev){
      var lmap=getMap(); if(!lmap) return;
      lmap.setView([ev.detail.lat,ev.detail.lon],ev.detail.zoom||17);
    });
    // Signal ready
    document.dispatchEvent(new CustomEvent("osm-bridge-ready"));
    setTimeout(function(){ document.dispatchEvent(new CustomEvent("osm-bridge-ready")); }, 1500);
    console.log("OSM Bridge ready");
  })();