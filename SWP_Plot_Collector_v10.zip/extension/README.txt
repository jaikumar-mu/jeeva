SWP Plot Collector v5.0 — Chrome / Edge
========================================
By B. Muthukumar (B.E), Madurai | swpcad.in
Built on TNGIS Plot Vertex Collector v4.0

WHAT'S NEW IN v5.0
------------------
- Login system: mobile OTP via Firebase Authentication
- Credit system: 1 credit per plot collected
- 5 FREE credits on new account registration
- Buy credits via Razorpay (50 / 150 / 500 plot plans)
- Credit balance shown in panel — updates in real time
- Session remembered across browser restarts
- Logout option available in panel

HOW TO INSTALL
--------------
1. Extract this ZIP folder
2. Open Chrome or Edge
3. Address bar → type: chrome://extensions
   (or edge://extensions for Edge)
4. Turn ON "Developer mode" (toggle at top-right)
5. Click "Load unpacked"
6. Select the extracted folder (containing content.js)
7. Done — extension installed

HOW TO USE
----------
1. Go to: https://tngis.tn.gov.in/apps/gi_viewer/
2. The SWP Plot Collector panel appears at bottom-right
3. First time: Login with mobile number + OTP
4. New users: 5 FREE plots credited automatically
5. Click any plot on the TNGIS map → collected automatically
   OR: select plot → click [Collect] button
6. 1 credit deducted per plot collected
7. Export: DXF (AutoCAD) button after collecting

CREDIT PLANS
------------
  5 plots    — FREE on signup (trial)
  50 plots   — ₹500  (₹10/plot)
  150 plots  — ₹1,200 (₹8/plot) ⭐ Popular
  500 plots  — ₹3,500 (₹7/plot)

BUY CREDITS
-----------
Click [💳 Buy Credits] in the panel
→ Select plan → Pay via Razorpay (UPI/Card/NetBanking)
→ WhatsApp Transaction ID to: +91 XXXXXXXXXX
→ Credits added within 30 minutes

WHAT THIS TOOL DOES
-------------------
- Works on tngis.tn.gov.in GIS viewer
- Click any plot → auto-collects all vertex lat/lon
- Shows SVG preview of plot boundary
- Area in 6 units: Sq.m, Sq.ft, Cents, Ares, Acres, Hectares
- Edge lengths shown on preview
- Multiple plot collection and comparison
- Total area calculation across all plots

EXPORT OPTIONS
--------------
  DXF      → AutoCAD file with metric projected coordinates
             (AutoCAD LIST/AREA shows correct sq.m)
  (CSV and CAD Text — coming in v5.1)

DXF LAYERS
----------
  S<SurveyNo>_SD<SubDiv> — closed polyline + edge lengths
  AREA_LABELS            — area label at plot centroid
  EDGE_LENGTHS           — segment length text on each side

NOTE: swpcad.in is an independent private service.
Not affiliated with Government of Tamil Nadu or TNGIS.

SUPPORT
-------
WhatsApp: +91 XXXXXXXXXX
Website:  swpcad.in
