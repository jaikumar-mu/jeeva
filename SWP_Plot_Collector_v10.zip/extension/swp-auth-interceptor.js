// swp-auth-interceptor.js — SWP Plot Collector
// Intercepts Firestore writes and adds Firebase Auth token
// Version: Final

(function () {
  'use strict';

  const FIREBASE_API = 'AIzaSyAY0ikv8LBCfELVf9lWYO2UWqFwFvr2y18';
  const AUTH_WORKER  = 'https://firebase-auth-worker.bmkumar07.workers.dev';
  const FIRESTORE_RE = /firestore\.googleapis\.com\/v1\/projects\/swpcad-plot-collector/;

  let _idToken   = null;
  let _tokenExp  = 0;
  let _tokenWait = null;
  let _uid       = null;

  const _origFetch = window.fetch.bind(window);
  window.__origFetch = _origFetch;

  async function signInWithCustomToken(customToken) {
    try {
      const resp = await _origFetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_API}`,
        {
          method : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body   : JSON.stringify({ token: customToken, returnSecureToken: true }),
        }
      );
      const data = await resp.json();
      if (data.idToken) {
        _idToken  = data.idToken;
        _tokenExp = Date.now() + parseInt(data.expiresIn) * 1000 - 60000;
        _uid      = data.localId;
        return true;
      }
      return false;
    } catch(e) { return false; }
  }

  async function getFirebaseToken(mobile) {
    try {
      const clean = String(mobile).replace(/\D/g,'').slice(-10);
      const resp  = await _origFetch(AUTH_WORKER + '/get-token', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ mobile: clean, project: 'swpcad' }),
      });
      const data = await resp.json();
      if (data.Status === 'Success' && data.firebaseToken) {
        await signInWithCustomToken(data.firebaseToken);
      }
    } catch(e) {}
  }

  window.fetch = async function (url, options = {}) {
    const urlStr = typeof url === 'string' ? url : (url?.url || String(url));
    const method = (options?.method || 'GET').toUpperCase();

    // Intercept workers.dev calls to get mobile/uid
    if (urlStr.includes('workers.dev') || urlStr.includes('vercel.app')) {
      const result = await _origFetch(url, options);
      const clone  = result.clone();
      try {
        const data = await clone.json();
        if (data?.Status === 'Success' || data?.ok === true) {
          // Try to get mobile from URL or body
          let mobile = null;
          try {
            const body = JSON.parse(options?.body || '{}');
            mobile = body.mobile || body.phone;
          } catch(e) {}
          if (!mobile) {
            const m = urlStr.match(/[?&]mobile=(\d+)/);
            if (m) mobile = m[1];
          }
          if (!mobile) {
            const m = urlStr.match(/\/(\d{10,12})/);
            if (m) mobile = m[1];
          }
          if (mobile && !_uid) {
            _tokenWait = getFirebaseToken(mobile);
          }
          if (data.uid) _uid = data.uid;
        }
      } catch(e) {}
      return result;
    }

    // Intercept Firestore writes — add auth token
    if (FIRESTORE_RE.test(urlStr) && (method === 'PATCH' || method === 'POST')) {
      // Extract uid from URL
      const m = urlStr.match(/users\/(user_\d+)/);
      if (m && !_uid) _uid = m[1];

      // Wait for token
      if (_tokenWait) { await _tokenWait; _tokenWait = null; }

      // Add auth header
      if (_idToken && Date.now() < _tokenExp) {
        options.headers = { ...(options.headers || {}), 'Authorization': `Bearer ${_idToken}` };
      }
    }

    return _origFetch(url, options);
  };

  console.log('[SWP Auth] Loaded ✅');
})();
