// ============================================================
// swp-auth-interceptor.js  —  SWP Plot Collector
// Inject BEFORE content.js in manifest.json
// Intercepts Firestore writes and adds Firebase Auth token
// ============================================================

(function () {
  'use strict';

  const PROJECT      = 'swpcad';
  const FIREBASE_API = 'AIzaSyAY0ikv8LBCfELVf9lWYO2UWqFwFvr2y18';
  const WORKER_URL   = 'https://firebase-auth-worker.bmkumar07.workers.dev';
  const FIRESTORE_RE = /firestore\.googleapis\.com\/v1\/projects\/swpcad-plot-collector/;

  let _idToken    = null;
  let _tokenExp   = 0;
  let _customToken = null;

  // ── Store Firebase token after OTP verify ──────────────────
  window.__SWP_setCustomToken = async function (mobile, otp, sessionId) {
    try {
      // Call our new Worker to verify OTP + get Firebase custom token
      const resp = await window.__origFetch(WORKER_URL + '/verify-otp', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ mobile, otp, sessionId, project: PROJECT }),
      });
      const data = await resp.json();

      if (data.Status !== 'Success') return null;

      // Exchange custom token for ID token
      const authResp = await window.__origFetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_API}`,
        {
          method : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body   : JSON.stringify({ token: data.firebaseToken, returnSecureToken: true }),
        }
      );
      const authData = await authResp.json();

      if (authData.idToken) {
        _idToken  = authData.idToken;
        _tokenExp = Date.now() + parseInt(authData.expiresIn) * 1000 - 60000;
        console.log('[SWP Auth] Firebase signed in. UID:', authData.localId);
        return data;
      }
      return null;
    } catch (e) {
      console.error('[SWP Auth] Token error:', e);
      return null;
    }
  };

  // ── Save original fetch ────────────────────────────────────
  window.__origFetch = window.fetch.bind(window);

  // ── Intercept fetch ───────────────────────────────────────
  window.fetch = async function (url, options = {}) {
    const urlStr = typeof url === 'string' ? url : (url.url || '');

    // Only intercept Firestore PATCH/GET calls for our project
    if (FIRESTORE_RE.test(urlStr)) {
      const method = (options.method || 'GET').toUpperCase();

      // For write operations — add Authorization header
      if (method === 'PATCH' || method === 'POST') {
        if (_idToken && Date.now() < _tokenExp) {
          options.headers = options.headers || {};
          options.headers['Authorization'] = `Bearer ${_idToken}`;
          console.log('[SWP Auth] Firestore write with auth token ✅');
        } else {
          console.warn('[SWP Auth] No valid token for Firestore write!');
        }
      }
    }

    return window.__origFetch(url, options);
  };

  // ── Intercept OTP verify call from existing Worker ────────
  // The existing extension calls its Worker for OTP verify
  // We intercept that response and ALSO call our Worker to get Firebase token
  const _origFetch2 = window.fetch;
  window.fetch = async function (url, options = {}) {
    const urlStr = typeof url === 'string' ? url : '';
    const result = await _origFetch2(url, options);

    // Check if this is an OTP verify call to existing Worker
    // Existing Worker returns { Status: "Success", Details: "..." }
    if (urlStr.includes('verify') && urlStr.includes('workers.dev')) {
      try {
        const clone = result.clone();
        const data  = await clone.json();

        if (data && data.Status === 'Success' && data.mobile && data.otp && data.sessionId) {
          // Get Firebase token in background
          window.__SWP_setCustomToken(data.mobile, data.otp, data.sessionId);
        }
      } catch (e) {
        // Not JSON or different structure — ignore
      }
    }

    return result;
  };

  console.log('[SWP Auth Interceptor] Loaded ✅');
})();
