SWP Plot Collector v5.9 (package v20) — WORKS WITH THE NEW TNGIS MAP VIEWER (Oct 2026)
====================================================================================
TNGIS changed its map viewer (…/gi_viewer/map-viewer/index.html, MapLibre map,
new "Land Parcel Information" box with icons). v20 supports it:
  • Circle Mode: the red circle is drawn again; clicking the map places the centre.
  • Collect ALL: auto-scans the circle on the new map (1 TNGIS lookup ≈ 1 plot;
    stays within your 50-lookup limit; press 📥 again later for the rest).
  • Plot shape is read directly from the new "Vertex" icon — no need to open
    the Vertex table; full-precision coordinates.
  • 🖼 Image works on the new map.
  • The old TNGIS viewer still works too.

IF IT STILL GETS 0 PLOTS: reload the TNGIS page (F5) once after installing.

SWP Plot Collector v5.8 (package v19) — NO AREA ON SCREEN (Oct 2026)
===================================================================
  • Area Calculator section removed from the panel.
  • Plot preview shows only the Survey No / Sub Division under the shape
    (no sq.m / Cents / Acres line).
  • Small fix: clicking a plot tab no longer logs an error in the console.
Everything else is the same as v18.

SWP Plot Collector v5.7 (package v18) — SURVEY NUMBER LABELS ONLY (Sep 2026)
===========================================================================
DXF label in each plot now shows ONLY:   Survey No / Sub Division   (e.g. 185/6)
  • No area lines any more (no sq.m, Cents, Acres) — with or without a circle.
  • Layer renamed AREA_LABELS → SURVEY_LABELS.
  • Edge lengths (EDGE_LENGTHS layer) and the circle (CIRCLE layer) unchanged.
  • The panel's Area Calculator still shows areas on screen.
Everything else is the same as v17.

SWP Plot Collector v5.6 (package v17) — ♾ UNLIMITED DXF PASS ₹1,200 (Sep 2026)
============================================================================
PLANS (Buy Credits screen)
  🟡 Trial          10 plots   ₹200    (credits: 1 per plot)
  🟢 Starter        50 plots   ₹500    (credits: 1 per plot)
  ♾  Unlimited DXF  UNLIMITED  ₹1,200  = 1 DXF export, any number of plots

HOW THE UNLIMITED DXF PASS WORKS
  • With a pass (badge "♾ Unlimited DXF × N" under your credits), collecting
    plots is FREE — click plots or 📥 Collect ALL, as many as you want,
    over as many TNGIS sessions as needed (💾 Save / 📂 Open).
  • 1 pass is used only when you press ⬇ DXF (it asks first).
  • Exporting the SAME plots again — now or later from a saved file — is free.
  • Adding new plots after that needs another pass (or credits).
  • Plots bought with credits never need a pass.

SERVER SETUP NEEDED (payment webhook)
  The ₹1,200 Razorpay payment must now ADD 1 to the user's Firestore field
  "dxfPasses" (instead of adding 150 credits). Until that is changed, a
  ₹1,200 payment will still add credits. Also rename the ₹1,200 Razorpay page
  to "Unlimited DXF export (1 DXF)".

SWP Plot Collector v5.5 (package v15) — SAVE / OPEN, COLLECT BIG AREAS IN PARTS (Sep 2026)
=======================================================================================
TNGIS gives about 50 lookups, then a 1-hour wait. To collect e.g. 500 plots:

  1. Place the circle → 📥 Collect ALL → ~50 lookups → plots collected.
  2. 💾 Save  → downloads  SWP_Plots_<n>plots_R<radius>m_<date>.swpplots
  3. After the TNGIS wait (any day, even after closing Chrome):
     📂 Open the file → plots + circle come back (no credits used).
  4. 📥 Collect ALL → only the MISSING plots are looked up and charged.
     Plots already in the file are skipped — never looked up, never charged.
  5. 💾 Save again (new file with all plots). Repeat 3–5 until complete.
  6. ⬇ DXF — one file with every plot.

  • ↺ Restore — if the TNGIS page is refreshed/closed by mistake, the panel
    offers "↺ Restore (N)" to bring back your last plots (same computer).
  • The file also remembers the fast TNGIS lookup method, so an opened file
    continues at full speed straight away.
  • Files are locked to your account and cannot be edited by hand
    (edited files are refused).
  • "Max TNGIS lookups per scan" now defaults to 50.
  • Export warning if none of your plots are inside the circle.

SWP Plot Collector v5.4 (package v14) — FIX: DXF showed only the circle (Sep 2026)
================================================================================
FIXED: collected (paid) plots could be left out of the DXF, giving a file
       with only the circle. Now a collected plot is NEVER dropped:
       • plots inside  → as before
       • plots crossing → clipped at the circle
       • plots outside the circle (e.g. the circle was moved after collecting)
         → exported in full, and the panel warns:
           "⚠ N outside the circle exported in full (was the circle moved?)"
NEW:   before charging, every plot's shape is checked (area 0.5 m² – 200 ha,
       corners near the circle). Plots with unreadable geometry are NOT
       charged.
TIP:   placing a new circle (click / Go / 🎯) moves the clip area. To export
       a circle's plots, export BEFORE placing another circle, or press
       Clear between areas.

SWP Plot Collector v5.3 (package v13) — RESPECTS THE TNGIS LOOKUP LIMIT (Sep 2026)
================================================================================
TNGIS allows each user only a limited number of "Land Details" lookups; when
it is used up TNGIS shows: "Land Details limit reached … Try again after …".
v13 works within that limit:

  • Stops at once when TNGIS shows its limit message (or refuses requests).
  • You are charged only for the plots found before it stopped.
  • "Max TNGIS lookups per scan" box (default 40) — the scan never uses more.
  • Before any one-by-one scan it asks you first (the one-request WFS method
    uses no Land Details lookups and does not ask).
  • If the limit message is already showing, it does not start at all.
  • Smarter scan order (wide grid first): about 2–3× more plots per lookup.
  • Press 📥 Collect ALL again later (after the TNGIS wait time) to add the
    remaining plots — plots you already have are skipped, not re-looked-up,
    not charged again.

Tip: to know your TNGIS limit, count how many plots you collect before the
red message appears, and set "Max TNGIS lookups" a little below it.

HOW TO USE
  1. Open https://tngis.tn.gov.in/apps/gi_viewer/ and log in (panel).
  2. Type the radius in the "m" box (e.g. 100).
  3. Click ⭕ Circle Mode → click the centre point ON A PLOT in the map.
     (Or: Lat/Lon + Go, or 🎯 Centre on plot.)
  4. The tool finds all plots inside/crossing the circle and asks:
        "Found N plots … Collect all for N credits?"  → OK
  5. Press ⬇ DXF.  All plots come in one file, clipped at the circle.

  • "Auto-collect ALL plots when circle is placed" (ticked) starts step 4 by
    itself. Untick it to collect later with 📥 Collect ALL plots in circle.
  • ■ Stop cancels a running scan. Nothing is charged until you press OK.
  • Plots you already collected are not charged again.
  • If credits are fewer than N, the nearest plots to the centre are
    collected up to your balance.

HOW IT FINDS THE PLOTS (automatic, fastest first)
  1. WFS      — one request to the TNGIS map server for the whole circle (seconds)
  2. Point    — quick point look-ups across the circle, no map clicking (seconds)
  3. Map scan — clicks the map inside the circle and reads each Vertex table
                (slow: minutes for a big circle; keep the tab open)
  The tool learns the TNGIS plot service from your first click on a plot, so
  always place the circle by clicking ON a plot (step 3). If it says
  "Could not read plots automatically", click any one plot, then press
  📥 Collect ALL plots in circle.

DXF (circle exports)
  • Inside plots: closed polyline, edge lengths, labels sized to the plot
    (Survey/SubDiv, sq.m, Cents)
  • Crossing plots: only the part inside the circle, "(part)", full area "(full)"
  • Layer CIRCLE: circle, centre point, R = … m, centre lat/lon
  • Untick "Clip plots at circle" to keep whole plots.
  • Without a circle, DXF output is exactly the same as v10.

REQUIRES Chrome / Edge 111+. Install: remove the old version at
chrome://extensions → Load unpacked → this folder.
--------------------------------------------------------------------------
WHAT'S NEW IN v5.0
------------------
- Login system: mobile OTP via Firebase Authentication
- Credit system: 1 credit per plot collected
- 5 FREE credits on new account registration
- Buy credits via Razorpay (see PLANS at the top)
- Credit balance shown in panel — updates in real time
- Session remembered across browser restarts
- Logout option available in panel

HOW TO INSTALL
--------------
1. Extract this ZIP folder
2. Open Chrome or Edge
3. Address bar → type: chrome://extensions
   (or edge://extensions for Edge)
4. Turn ON "Developer mode" (toggle at top-right)
5. Click "Load unpacked"
6. Select the extracted folder (containing content.js)
7. Done — extension installed

HOW TO USE
----------
1. Go to: https://tngis.tn.gov.in/apps/gi_viewer/
2. The SWP Plot Collector panel appears at bottom-right
3. First time: Login with mobile number + OTP
4. New users: 5 FREE plots credited automatically
5. Click any plot on the TNGIS map → collected automatically
   OR: select plot → click [Collect] button
6. 1 credit deducted per plot collected
7. Export: DXF (AutoCAD) button after collecting

CREDIT PLANS
------------
  10 plots        — ₹200
  50 plots        — ₹500
  Unlimited plots — ₹1,200 per DXF export

BUY CREDITS
-----------
Click [💳 Buy Credits] in the panel
→ Select plan → Pay via Razorpay (UPI/Card/NetBanking)
→ WhatsApp Transaction ID to: +91 XXXXXXXXXX
→ Credits added within 30 minutes

WHAT THIS TOOL DOES
-------------------
- Works on tngis.tn.gov.in GIS viewer
- Click any plot → auto-collects all vertex lat/lon
- Shows SVG preview of plot boundary
- Area in 6 units: Sq.m, Sq.ft, Cents, Ares, Acres, Hectares
- Edge lengths shown on preview
- Multiple plot collection and comparison
- Total area calculation across all plots

EXPORT OPTIONS
--------------
  DXF      → AutoCAD file with metric projected coordinates
             (AutoCAD LIST/AREA shows correct sq.m)
  (CSV and CAD Text — coming in v5.1)

DXF LAYERS
----------
  S<SurveyNo>_SD<SubDiv> — closed polyline + edge lengths
  SURVEY_LABELS          — Survey No / Sub Division at plot centre
  EDGE_LENGTHS           — segment length text on each side

NOTE: swpcad.in is an independent private service.
Not affiliated with Government of Tamil Nadu or TNGIS.

SUPPORT
-------
WhatsApp: +91 XXXXXXXXXX
Website:  swpcad.in
