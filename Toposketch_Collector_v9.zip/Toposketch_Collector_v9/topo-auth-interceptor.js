// ============================================================
// topo-auth-interceptor.js  —  Toposketch Collector
// Inject BEFORE content.js in manifest.json
// Intercepts Firestore writes and adds Firebase Auth token
// ============================================================

(function () {
  'use strict';

  const PROJECT      = 'topo';
  const FIREBASE_API = 'AIzaSyCIz_UEGdlvTjEvmTXm1nunr8SOIAt1ruM';
  const WORKER_URL   = 'https://firebase-auth-worker.bmkumar07.workers.dev';
  const FIRESTORE_RE = /firestore\.googleapis\.com\/v1\/projects\/toposketch-collector/;

  let _idToken  = null;
  let _tokenExp = 0;

  // ── Store Firebase token after OTP verify ──────────────────
  window.__TOPO_setCustomToken = async function (mobile, otp, sessionId) {
    try {
      const resp = await window.__origFetch(WORKER_URL + '/verify-otp', {
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body   : JSON.stringify({ mobile, otp, sessionId, project: PROJECT }),
      });
      const data = await resp.json();

      if (data.Status !== 'Success') return null;

      const authResp = await window.__origFetch(
        `https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=${FIREBASE_API}`,
        {
          method : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body   : JSON.stringify({ token: data.firebaseToken, returnSecureToken: true }),
        }
      );
      const authData = await authResp.json();

      if (authData.idToken) {
        _idToken  = authData.idToken;
        _tokenExp = Date.now() + parseInt(authData.expiresIn) * 1000 - 60000;
        console.log('[TOPO Auth] Firebase signed in. UID:', authData.localId);
        return data;
      }
      return null;
    } catch (e) {
      console.error('[TOPO Auth] Token error:', e);
      return null;
    }
  };

  // ── Save original fetch ────────────────────────────────────
  window.__origFetch = window.fetch.bind(window);

  // ── Intercept fetch ───────────────────────────────────────
  window.fetch = async function (url, options = {}) {
    const urlStr = typeof url === 'string' ? url : (url.url || '');

    // Intercept Firestore PATCH/POST calls for toposketch project
    if (FIRESTORE_RE.test(urlStr)) {
      const method = (options.method || 'GET').toUpperCase();

      if (method === 'PATCH' || method === 'POST') {
        if (_idToken && Date.now() < _tokenExp) {
          options.headers = options.headers || {};
          options.headers['Authorization'] = `Bearer ${_idToken}`;
          console.log('[TOPO Auth] Firestore write with auth token ✅');
        } else {
          console.warn('[TOPO Auth] No valid token for Firestore write!');
        }
      }
    }

    // Also intercept OTP verify calls to get Firebase token
    const result = await window.__origFetch(url, options);

    if (urlStr.includes('verify') && urlStr.includes('workers.dev')) {
      try {
        const clone = result.clone();
        const data  = await clone.json();
        if (data && data.Status === 'Success' && data.mobile && data.otp && data.sessionId) {
          window.__TOPO_setCustomToken(data.mobile, data.otp, data.sessionId);
        }
      } catch (e) {}
    }

    return result;
  };

  console.log('[TOPO Auth Interceptor] Loaded ✅');
})();
